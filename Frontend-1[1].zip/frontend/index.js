// initialize
const express = require('express');
const app = express();

// set EJS
app.set('view engine', 'ejs');
app.set('views','./views'); 

//home Page route
app.get('/',function(req,res){
    res.render('index');
});

//login Page route
app.get('/login',function(req,res){
    res.render('login');
});

//airports Page route
app.get('/airports',function(req,res){
    res.render('airports');
});

//addairport Page route
app.get('/addairport',function(req,res){
    res.render('addairport');
});

//updateairport Page route
app.get('/updateairport',function(req,res){
    res.render('updateairport');
});

//planes Page route
app.get('/planes',function(req,res){
    res.render('planes');
});

//addplane Page route
app.get('/addplane',function(req,res){
    res.render('addplane');
});

//updateplane Page route
app.get('/updateplane',function(req,res){
    res.render('updateplane');
});

//flights Page route
app.get('/flights',function(req,res){
    res.render('flights');
});

//addflight Page route
app.get('/addflight',function(req,res){
    res.render('addflight');
});



//set port to 8000
app.listen(8000);